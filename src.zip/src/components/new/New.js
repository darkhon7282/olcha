import React, { useEffect, useState } from 'react'
import "./New.css"

import phone from "../../assets/newpro/phone.png"
import ayol from "../../assets/newpro/ayol.png"
import avto from "../../assets/newpro/avto.png"
import forman from "../../assets/newpro/forman.png"
import tv from "../../assets/newpro/tv.png"
import bolalar from "../../assets/newpro/bolalar.png"
import moyka from "../../assets/newpro/moyka.png"
import kosmetika from "../../assets/newpro/kosmetika.png"
import gamer from "../../assets/newpro/gamer.png"
import kidclothes from "../../assets/newpro/kidclothes.png"
import fara from "../../assets/newpro/fara.png"
import makeup from "../../assets/newpro/makeup.png"
import laptop from "../../assets/newpro/laptop.png"
import arava from "../../assets/newpro/arava.png"
import rul from "../../assets/newpro/rul.png"
import hair from "../../assets/newpro/hair.png"


import { db } from "../../server"
import { collection, getDocs, doc, deleteDoc } from "firebase/firestore"

function New({admin}) {
    const[refresh, setRefresh] = useState(false)
    
    const [data, setNewData] = useState([])

    const categoriesColRef = collection(db, "category")


    useEffect(()=>{
        const getCategories = async () => {
            const categories = await getDocs(categoriesColRef)
            setNewData(categories.docs.map((po)=> ({...po.data(), id: po.id })))
        }
        getCategories()
    }, [refresh])

  console.log(data);


  const deleteNew = async (id)=>{
    await deleteDoc(doc(db, "category", id))
      .then(res=> {
        console.log(res)
        setRefresh(!refresh)
      })
      .catch(res=> console.log(res))
  }




  return (
    <div className='new__products'>
        <h1>Kategoriyadagi yangi mahsulotlar</h1>
            <div className="new__category_front">
                {
                    data?.map((item, inx)=>
                        <div key={inx} className="new__category">
                            <img src={item.pic} alt="" />
                            <p>{item.text}</p>
                            {
                                admin ? 
                                <button onClick={()=> deleteNew(item.id)}>delete</button>
                                :
                                <></>
                            }
                        </div>
                    )
                }
            </div>
        
    </div>
  )
}

export default New