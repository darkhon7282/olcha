export const ADD_TO_LIKE = "ADD_TO_LIKE"
export const REMOVE_LIKE = "REMOVE_LIKE"
export const ADD_TO_CART = "ADD_TO_CART"
export const REMOVE_CART = "REMOVE_CART"