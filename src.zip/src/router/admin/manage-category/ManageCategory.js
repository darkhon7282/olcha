import React from 'react'
import New from '../../../components/new/New'

function ManageCategory() {
  return (
    <div>
        <h2>ManageCategory</h2>
        <New admin= {true}/>
    </div>
  )
}

export default ManageCategory